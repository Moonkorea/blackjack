
#include "stage.h"

static void logic(void);
static void draw(void);

static void resetStage(void);

static void drawDebris(void);
static void drawHud(void);


static Entity *player;
static SDL_Texture *pointsTexture;

static int enemySpawnTimer;
static int stageResetTimer;

static SDL_Texture *targetterTexture;
static SDL_Texture *bettingTexture;


void initStage(void)
{
	app.delegate.logic = logic;
	app.delegate.draw = draw;

	targetterTexture = loadTexture("gfx/targetter.png");
	bettingTexture = loadTexture("gfx/betting.png");
	
	
	pointsTexture = loadTexture("gfx/points.png");
	
	memset(app.keyboard, 0, sizeof(int) * MAX_KEYBOARD_KEYS);

	initStageBackground();
	
	resetStage();
	
	stage.score = 0;
	
	enemySpawnTimer = 0;
	
	stageResetTimer = FPS * 3;
}

static void resetStage(void)
{
	Entity *e;
	Explosion *ex;
	Debris *d;
	
	while (stage.fighterHead.next)
	{
		e = stage.fighterHead.next;
		stage.fighterHead.next = e->next;
		free(e);
	}
	
	while (stage.bulletHead.next)
	{
		e = stage.bulletHead.next;
		stage.bulletHead.next = e->next;
		free(e);
	}
	
	while (stage.explosionHead.next)
	{
		ex = stage.explosionHead.next;
		stage.explosionHead.next = ex->next;
		free(ex);
	}
	
	while (stage.debrisHead.next)
	{
		d = stage.debrisHead.next;
		stage.debrisHead.next = d->next;
		free(d);
	}
	
	while (stage.pointsHead.next)
	{
		e = stage.pointsHead.next;
		stage.pointsHead.next = e->next;
		free(e);
	}
	
	memset(&stage, 0, sizeof(Stage));
	stage.fighterTail = &stage.fighterHead;
	stage.bulletTail = &stage.bulletHead;
	stage.explosionTail = &stage.explosionHead;
	stage.debrisTail = &stage.debrisHead;
	stage.pointsTail = &stage.pointsHead;
}


static void logic(void)
{
	if (player == NULL && --stageResetTimer <= 0)
	{
		addHighscore(stage.score);
	}
	
}

static void draw(void)
{
	
	drawBackground();
	drawDebris();	
	drawHud();

	blit(bettingTexture, 340, 300);

	if (app.keyboard[SDL_SCANCODE_1])
	{
		bettingTexture = NULL;	
	}

	int x,y;
		x= app.mouse.x;
		y= app.mouse.y;

	if (app.mouse.button[SDL_BUTTON_LEFT]){
			if(x>900 && x<1280 && y>640 && y<720){
				blit(bettingTexture, 800, 100);
			}
	}

	blit1(targetterTexture, app.mouse.x, app.mouse.y, 1);
}

static void drawDebris(void)
{
	Debris *d;
	
	for (d = stage.debrisHead.next ; d != NULL ; d = d->next)
	{
		blitRect(d->texture, &d->rect, d->x, d->y);
	}
}


static void drawHud(void)
{
	drawText(10, 10, 255, 255, 255, TEXT_LEFT, "SCORE: %03d", stage.score);
	
	if (stage.score < highscores.highscore[0].score)
	{
		drawText(SCREEN_WIDTH - 10, 10, 255, 255, 255, TEXT_RIGHT, "HIGHSCORE: %03d", highscores.highscore[0].score);
	}
	else
	{
		drawText(SCREEN_WIDTH - 10, 10, 0, 255, 0, TEXT_RIGHT, "HIGHSCORE: %03d", stage.score);
	}
}
